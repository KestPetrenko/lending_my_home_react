let stroke = {
    header : {
        link1: "ABOUT",
        link2: "BEDROOM",
        link3: "LIVING ROOM",
        link4: "KITCHEN",
        link5: "BABIES",
        link6: "THE NEW",
        link7: "CONTACT",
        link8: "MEMBERSHIP",
    }
}

export default stroke;