import React from 'react';
import './Article.css'

const Article = () => {
    return (
        <div id="article">
            <div>Lorem ipsum dolor sit amet, consectetur.</div>
            <div>Far far away, behind the word mountains, far from the</div>
            <div>The quick, brown</div>
            <div>Home, sweet home</div>
        </div>
    );
}

export default Article;