import React from 'react';
import './Aside.css'
import yellow from '../img/yellow.png'

const Aside = () => {
  return (
      <div id='aside-4'>
          <img src={yellow} alt="yellow"/>
      </div>
  );
}

export default Aside;