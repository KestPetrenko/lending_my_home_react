import React from 'react';
import './Article.css'

const Article = () => {
    return (
        <div id="article-4">
            <div>The quick, brown fox jumps over a lazy dog. DJs Lorem ipsum.</div>
            <div id='second'>One morning, when Gregor Samsa woke</div>
            <div id="sign-up-4">
                <input type="text"/>
                <div id='sign-div'>sign up</div>
            </div>
            <div>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of</div>
        </div>
    );
}

export default Article;