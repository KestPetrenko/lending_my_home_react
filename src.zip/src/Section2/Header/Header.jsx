import React from 'react';
import './Header.css'

const Header = () => {
    return (
        <header id="header2">
            <h1>
                Tips to decorate your home
            </h1>
        </header>
    );
}

export default Header;