import React from "react";
import './rightSection9.css';
import img7 from "../img/logo.png";

const RightSection = () => {
    return (
        <div className="div_section9">
            <img src={img7} className="img7"/>
        </div>

    )
}

export default RightSection;