import React from "react";
import "../divLeft/divLeft.css";

const DivLeft = () => {
    return (
        <div className="img5"></div>
    )
}

export default DivLeft;