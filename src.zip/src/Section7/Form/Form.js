import React from "react";
import "./Form.css"


const Form = () => {
    return (
        <form>
            <input placeholder="Select Event"/>
            <input placeholder="Name"/>
            <input placeholder="Email"/>
            <button id="sign-div1">Sing Up</button>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut
                laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation
                ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor
            </p>
        </form>
    )
}

export default Form;