import React from "react";
import "./Text.css"

const Text = () => {
    return (
        <h1>Open your gift table here. <br/>
            Gifts with direct delivery to your home</h1>
    )
}

export default Text;