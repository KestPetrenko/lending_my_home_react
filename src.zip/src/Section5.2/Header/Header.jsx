import React from "react";
import './Header.css'

const Header = () => {
    return (
        <div id="header5_2">
            buy now
        </div>
    )
}

export default Header