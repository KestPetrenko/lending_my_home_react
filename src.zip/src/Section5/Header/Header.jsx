import React from "react";
import './Header.css'

const Header = () => {
    return (
        <div id="header-5">
            new season
        </div>
    );
}

export default Header;